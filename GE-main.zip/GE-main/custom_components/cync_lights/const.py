"""Constants for the Cync Room Lights integration."""

DOMAIN = "cync_lights"